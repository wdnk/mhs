<?php
// koneksi ke mysql
mysql_connect('localhost', 'akadft', 'teknik0417');
mysql_select_db('akadft_akdemikft');
?>