<?php
$db_name = "akadft_akdemikft";
$db_user = "akadft";
$db_pass = "teknik0417";
$db_host = "localhost";
?>