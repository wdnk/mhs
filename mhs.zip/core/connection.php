<?php

$connection = mysqli_connect($db_host,$db_user,$db_pass,$db_name) or die("Cannot connect to database! Check your database setting!");
//$connection2 = mysqli_connect($db_host,$db_user,$db_pass,$db_name2) or die("Cannot connect to database! Check your database setting!");

?>