The DHTML Calendar 0.9.6

This directory contains the javascript code
of the DHTML Calendar 0.9.6

Refer to http://www.dynarch.com/projects/calendar/
for more details about the product.