    <?php
		include "koneksi.php";
        mail("eko_magelang@yahoo.com","test","halooo","From: admin@planetkomputer.com");
        echo "<h1>Status Email</h1>
              <p>Email telah sukses terkirim ke tujuan</p>";
    ?> 